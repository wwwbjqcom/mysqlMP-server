function pagenition() {
    all_tb_data = [
        {"filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],"cluster_name": "test1","node_list":
                [
                    {"host": "host1", "dbport": "dbport1", "cluster_name": "cluster_name1", "role": "role1", "online": "false"},
                    {"host": "host11", "dbport": "dbport11"},
                    {"host": "host111", "dbport": "dbport111"},
                    {"host": "host1111", "dbport": "dbport1111"},
                ]
        },
        {"cluster_name": "test2","filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"], "node_list":
                [
                    {"host": "host2", "dbport": "dbport2"},
                    {"host": "host22", "dbport": "dbport22"},
                    {"host": "host222", "dbport": "dbport222"},
                    {"host": "host2222", "dbport": "dbport2222"},
                ]
        },
        {"cluster_name": "test3","filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"], "node_list":
                [
                    {"host": "host3", "dbport": "dbport3"},
                    {"host": "host33", "dbport": "dbport33"},
                    {"host": "host333", "dbport": "dbport333"},
                ]
        }
    ];
    //数据的长度
    var all_data_length = all_tb_data.length;
    //每页的数量
    var per_page_num = 1;
    //需要展示的按钮
    var need_show_button = Math.ceil(all_data_length/per_page_num);
    //当前页
    var current_page = "";
    //下一页
    var next_page = "";
    //第一页
    var first_page = "";

    var $page_ul = $("#page_ul");
    $page_ul.empty();
    $page_ul.append("<li><a>&laquo;</a></li>");
    for(var page_num=1; page_num < 10; page_num++){
        $page_ul.append("<li><a class='pageactive'>"+ page_num +"</a></li>");
    }
    $page_ul.append("<li><a>&raquo;</a></li>");
    var children_length = $page_ul.children().length;
    if(children_length > 10){
        //$page_ul.children().eq(3).children().addClass("page_active");
        $page_ul.children().eq(6).children().text("...")
    }

}

function click_page(){

}
pagenition();
//用于选择当前页
$("#page_ul li a").click(function () {
    console.log("111111");
    $("#page_ul li a").css("background", "");
    $(this).css("background", "#aaa");

});


var all_tb_data_test = [
    {
        // "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "cluster_name": "test1",
        "node_list":
            [
                {
                    "host": "host1",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "online": "false"
                },
                {
                    "host": "host11",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "role11",
                    "online": "true"
                },
                {
                    "host": "host111",
                    "dbport": "dbport111",
                    "cluster_name": "cluster_name111",
                    "role": "role111",
                    "online": "true"
                },
                {
                    "host": "host1111",
                    "dbport": "dbport1111",
                    "cluster_name": "cluster_name1111",
                    "role": "role1111",
                    "online": "true"

                },
            ]
    },
    {
        "cluster_name": "test2",
        "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "node_list":
            [
                {
                    "host": "host1",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "online": "false"
                },
                {
                    "host": "host11",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "role11",
                    "online": "true"
                },
                {
                    "host": "host111",
                    "dbport": "dbport111",
                    "cluster_name": "cluster_name111",
                    "role": "role111",
                    "online": "true"
                },
                {
                    "host": "host1111",
                    "dbport": "dbport1111",
                    "cluster_name": "cluster_name1111",
                    "role": "role1111",
                    "online": "true"

                },
            ]
    },
    {
        "cluster_name": "test3",
        "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "node_list":
            [
                {
                    "host": "host1",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "online": "false"
                },
                {
                    "host": "host11",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "role11",
                    "online": "true"
                },
                {
                    "host": "host111",
                    "dbport": "dbport111",
                    "cluster_name": "cluster_name111",
                    "role": "role111",
                    "online": "true"
                },
                {
                    "host": "host1111",
                    "dbport": "dbport1111",
                    "cluster_name": "cluster_name1111",
                    "role": "role1111",
                    "online": "true"

                },
            ]
    },
    {
        "cluster_name": "test22",
        "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "node_list":
            [
                {
                    "host": "host1",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "online": "false"
                },
                {
                    "host": "host11",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "role11",
                    "online": "true"
                },
                {
                    "host": "host111",
                    "dbport": "dbport111",
                    "cluster_name": "cluster_name111",
                    "role": "role111",
                    "online": "true"
                },
                {
                    "host": "host1111",
                    "dbport": "dbport1111",
                    "cluster_name": "cluster_name1111",
                    "role": "role1111",
                    "online": "true"

                },
            ]
    },
    {
        "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "cluster_name": "test11",
        "node_list":
            [
                {
                    "host": "host1",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "online": "false"
                },
                {
                    "host": "host11",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "role11",
                    "online": "true"
                },
                {
                    "host": "host111",
                    "dbport": "dbport111",
                    "cluster_name": "cluster_name111",
                    "role": "role111",
                    "online": "true"
                },
                {
                    "host": "host1111",
                    "dbport": "dbport1111",
                    "cluster_name": "cluster_name1111",
                    "role": "role1111",
                    "online": "true"

                },
            ]
    },
    {
        "cluster_name": "test33",
        "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "node_list":
            [
                {
                    "host": "host1",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "online": "false"
                },
                {
                    "host": "host11",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "role11",
                    "online": "true"
                },
                {
                    "host": "host111",
                    "dbport": "dbport111",
                    "cluster_name": "cluster_name111",
                    "role": "role111",
                    "online": "true"
                },
                {
                    "host": "host1111",
                    "dbport": "dbport1111",
                    "cluster_name": "cluster_name1111",
                    "role": "role1111",
                    "online": "true"

                },
            ]
    },
];
var all_data_length = all_tb_data_test.length;

var all_data = [
    {
        // "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "cluster_name": "test1",
        "node_list":
            [
                {
                    "host": "host1",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "online": "false",
                    "maintain": "false",
                    "rtype": "db",
                },
                {
                    "host": "host11",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "role11",
                    "online": "true",
                    "maintain": "true",
                    "rtype": "route",
                },
                {
                    "host": "host111",
                    "dbport": "dbport111",
                    "cluster_name": "cluster_name111",
                    "role": "role111",
                    "online": "true",
                    "maintain": "true",
                    "rtype": "route",
                },
                {
                    "host": "host1111",
                    "dbport": "dbport1111",
                    "cluster_name": "cluster_name1111",
                    "role": "role1111",
                    "online": "true",
                    "maintain": "true",
                    "rtype": "route",

                },
            ]
    },
    {
        "cluster_name": "test2",
        "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "node_list":
            [
                {
                    "host": "host1",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "online": "false",
                    "maintain": "false",
                },
                {
                    "host": "host11",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "role11",
                    "online": "true",
                    "maintain": "true",
                },
                {
                    "host": "host111",
                    "dbport": "dbport111",
                    "cluster_name": "cluster_name111",
                    "role": "role111",
                    "online": "true",
                    "maintain": "true",
                },
                {
                    "host": "host1111",
                    "dbport": "dbport1111",
                    "cluster_name": "cluster_name1111",
                    "role": "role1111",
                    "online": "true",
                    "maintain": "true",

                },
            ]
    },
    {
        "cluster_name": "test3",
        "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "node_list":
            [
                {
                    "host": "host1",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "online": "false",
                    "maintain": "false",
                },
                {
                    "host": "host11",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "role11",
                    "online": "true",
                    "maintain": "true",
                },
                {
                    "host": "host111",
                    "dbport": "dbport111",
                    "cluster_name": "cluster_name111",
                    "role": "role111",
                    "online": "true",
                    "maintain": "true",
                },
                {
                    "host": "host1111",
                    "dbport": "dbport1111",
                    "cluster_name": "cluster_name1111",
                    "role": "role1111",
                    "online": "true",
                    "maintain": "true",

                },
            ]
    },
    {
        "cluster_name": "test22",
        "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "node_list":
            [
                {
                    "host": "host1",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "online": "false",
                    "maintain": "false",
                },
                {
                    "host": "host11",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "role11",
                    "online": "true",
                    "maintain": "true",
                },
                {
                    "host": "host111",
                    "dbport": "dbport111",
                    "cluster_name": "cluster_name111",
                    "role": "role111",
                    "online": "true",
                    "maintain": "true",
                },
                {
                    "host": "host1111",
                    "dbport": "dbport1111",
                    "cluster_name": "cluster_name1111",
                    "role": "role1111",
                    "online": "true",
                    "maintain": "true",

                },
            ]
    },
    {
        "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "cluster_name": "test11",
        "node_list":
            [
                {
                    "host": "host1",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "online": "false",
                    "maintain": "false",
                },
                {
                    "host": "host11",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "role11",
                    "online": "true",
                    "maintain": "true",
                },
                {
                    "host": "host111",
                    "dbport": "dbport111",
                    "cluster_name": "cluster_name111",
                    "role": "role111",
                    "online": "true",
                    "maintain": "true",
                },
                {
                    "host": "host1111",
                    "dbport": "dbport1111",
                    "cluster_name": "cluster_name1111",
                    "role": "role1111",
                    "online": "true",
                    "maintain": "true",

                },
                {
                    "host": "host1111",
                    "dbport": "dbport1111",
                    "cluster_name": "cluster_name1111",
                    "role": "role1111",
                    "online": "true",
                    "maintain": "false",

                },
                {
                    "host": "host1111",
                    "dbport": "dbport1111",
                    "cluster_name": "cluster_name1111",
                    "role": "role1111",
                    "online": "true",
                    "maintain": "false",

                },
            ]
    },
    {
        "cluster_name": "test33",
        "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "node_list":
            [
                {
                    "host": "host1",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "online": "false",
                    "maintain": "false",
                },
                {
                    "host": "host11",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "role11",
                    "online": "true",
                    "maintain": "true",
                },
                {
                    "host": "host111",
                    "dbport": "dbport111",
                    "cluster_name": "cluster_name111",
                    "role": "role111",
                    "online": "true",
                    "maintain": "true",
                },
                {
                    "host": "host1111",
                    "dbport": "dbport1111",
                    "cluster_name": "cluster_name1111",
                    "role": "role1111",
                    "online": "true",
                    "maintain": "true",

                },
            ]
    },
    {
        "cluster_name": "test34",
        "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "node_list":
            [
                {
                    "host": "host1",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "online": "false",
                    "maintain": "false",
                },
                {
                    "host": "host11",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "role11",
                    "online": "true",
                    "maintain": "true",
                },

            ]
    },
    {
        "cluster_name": "test35",
        "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "node_list":
            [
                {
                    "host": "host1",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "online": "false",
                    "maintain": "false",
                },
                {
                    "host": "host11",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "role11",
                    "online": "true",
                    "maintain": "true",
                },

            ]
    },
    {
        "cluster_name": "test36",
        "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "node_list":
            [
                {
                    "host": "host1",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "online": "false",
                    "maintain": "false",
                },
                {
                    "host": "host11",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "role11",
                    "online": "true",
                    "maintain": "true",
                },

            ]
    },
    {
        "cluster_name": "test37",
        "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "node_list":
            [
                {
                    "host": "host1",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "rtype": "db",
                    "online": "false",
                    "maintain": "false",
                },
                {
                    "host": "host11",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "role11",
                    "online": "true",
                    "maintain": "true",
                },

            ]
    },
];

all_data = [
    {
        // "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "cluster_name": "test1",
        "node_list":
            [
                {
                    "host": "host1",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "online": "false",
                    "maintain": "false",
                    "rtype": "db",
                },
                {
                    "host": "host11",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "",
                    "online": "true",
                    "maintain": "false",
                    "rtype": "route",
                },
                {
                    "host": "host111",
                    "dbport": "dbport111",
                    "cluster_name": "cluster_name111",
                    "role": "",
                    "online": "true",
                    "maintain": "false",
                    "rtype": "route",
                },
                {
                    "host": "host1111",
                    "dbport": "dbport1111",
                    "cluster_name": "cluster_name1111",
                    "role": "role1111",
                    "online": "true",
                    "maintain": "true",
                    "rtype": "route",

                },
            ]
    },
    {
        "cluster_name": "test2",
        "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "node_list":
            [
                {
                    "host": "127.0.0.1:9001",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "online": "false",
                    "maintain": "false",
                },
                {
                    "host": "127.0.0.1:9013",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "role11",
                    "online": "true",
                    "maintain": "true",
                },
                {
                    "host": "host111",
                    "dbport": "dbport111",
                    "cluster_name": "cluster_name111",
                    "role": "role111",
                    "online": "true",
                    "maintain": "true",
                },
                {
                    "host": "host1111",
                    "dbport": "dbport1111",
                    "cluster_name": "cluster_name1111",
                    "role": "role1111",
                    "online": "true",
                    "maintain": "true",

                },
            ]
    },
    {
        "cluster_name": "test3",
        "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "node_list":
            [
                {
                    "host": "host1",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "online": "false",
                    "maintain": "false",
                },
                {
                    "host": "host11",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "role11",
                    "online": "true",
                    "maintain": "true",
                },
                {
                    "host": "host111",
                    "dbport": "dbport111",
                    "cluster_name": "cluster_name111",
                    "role": "role111",
                    "online": "true",
                    "maintain": "true",
                },
                {
                    "host": "host1111",
                    "dbport": "dbport1111",
                    "cluster_name": "cluster_name1111",
                    "role": "role1111",
                    "online": "true",
                    "maintain": "true",

                },
            ]
    },
    {
        "cluster_name": "test22",
        "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "node_list":
            [
                {
                    "host": "host1",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "online": "false",
                    "maintain": "false",
                },
                {
                    "host": "host11",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "role11",
                    "online": "true",
                    "maintain": "true",
                },
                {
                    "host": "host111",
                    "dbport": "dbport111",
                    "cluster_name": "cluster_name111",
                    "role": "role111",
                    "online": "true",
                    "maintain": "true",
                },
                {
                    "host": "host1111",
                    "dbport": "dbport1111",
                    "cluster_name": "cluster_name1111",
                    "role": "role1111",
                    "online": "true",
                    "maintain": "true",

                },
            ]
    },
    {
        "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "cluster_name": "test11",
        "node_list":
            [
                {
                    "host": "host1",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "online": "false",
                    "maintain": "false",
                },
                {
                    "host": "host11",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "role11",
                    "online": "true",
                    "maintain": "true",
                },
                {
                    "host": "host111",
                    "dbport": "dbport111",
                    "cluster_name": "cluster_name111",
                    "role": "role111",
                    "online": "true",
                    "maintain": "true",
                },
                {
                    "host": "host1111",
                    "dbport": "dbport1111",
                    "cluster_name": "cluster_name1111",
                    "role": "role1111",
                    "online": "true",
                    "maintain": "true",

                },
                {
                    "host": "host1111",
                    "dbport": "dbport1111",
                    "cluster_name": "cluster_name1111",
                    "role": "role1111",
                    "online": "true",
                    "maintain": "false",

                },
                {
                    "host": "host1111",
                    "dbport": "dbport1111",
                    "cluster_name": "cluster_name1111",
                    "role": "role1111",
                    "online": "true",
                    "maintain": "false",

                },
            ]
    },
    {
        "cluster_name": "test33",
        "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "node_list":
            [
                {
                    "host": "host1",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "online": "false",
                    "maintain": "false",
                },
                {
                    "host": "host11",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "role11",
                    "online": "true",
                    "maintain": "true",
                },
                {
                    "host": "host111",
                    "dbport": "dbport111",
                    "cluster_name": "cluster_name111",
                    "role": "role111",
                    "online": "true",
                    "maintain": "true",
                },
                {
                    "host": "host1111",
                    "dbport": "dbport1111",
                    "cluster_name": "cluster_name1111",
                    "role": "role1111",
                    "online": "true",
                    "maintain": "true",

                },
            ]
    },
    {
        "cluster_name": "test34",
        "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "node_list":
            [
                {
                    "host": "host1",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "online": "false",
                    "maintain": "false",
                },
                {
                    "host": "host11",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "role11",
                    "online": "true",
                    "maintain": "true",
                },

            ]
    },
    {
        "cluster_name": "test35",
        "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "node_list":
            [
                {
                    "host": "host1",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "online": "false",
                    "maintain": "false",
                },
                {
                    "host": "host11",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "role11",
                    "online": "true",
                    "maintain": "true",
                },

            ]
    },
    {
        "cluster_name": "test36",
        "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "node_list":
            [
                {
                    "host": "host1",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "online": "false",
                    "maintain": "false",
                },
                {
                    "host": "host11",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "role11",
                    "online": "true",
                    "maintain": "true",
                },

            ]
    },
    {
        "cluster_name": "test37",
        "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "node_list":
            [
                {
                    "host": "host1",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "rtype": "db",
                    "online": "false",
                    "maintain": "false",
                },
                {
                    "host": "host11",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "role11",
                    "online": "true",
                    "maintain": "true",
                },

            ]
    },
];


all_data = [
    {
        // "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "cluster_name": "test1",
        "node_list":
            [
                {
                    "host": "host1",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "online": "false",
                    "maintain": "false",
                    "rtype": "db",
                },
                {
                    "host": "host11",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "",
                    "online": "true",
                    "maintain": "false",
                    "rtype": "route",
                },
            ]
    },
    {
        // "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "cluster_name": "test99",
        "node_list":
            [
                {
                    "host": "host1",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "online": "false",
                    "maintain": "false",
                    "rtype": "route",
                },
                {
                    "host": "host11",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "",
                    "online": "true",
                    "maintain": "false",
                    "rtype": "route",
                },
                {
                    "host": "host111",
                    "dbport": "dbport111",
                    "cluster_name": "cluster_name111",
                    "role": "",
                    "online": "true",
                    "maintain": "false",
                    "rtype": "route",
                },

            ]
    },
    {
        "cluster_name": "test2",
        "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "node_list":
            [
                {
                    "host": "127.0.0.1:9001",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "online": "false",
                    "maintain": "false",
                },
                {
                    "host": "127.0.0.1:9013",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "role11",
                    "online": "true",
                    "maintain": "true",
                },
            ]
    },
    {
        "cluster_name": "test3",
        "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "node_list":
            [
                {
                    "host": "host1",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "online": "false",
                    "maintain": "false",
                },
                {
                    "host": "host11",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "role11",
                    "online": "true",
                    "maintain": "true",
                },
                {
                    "host": "host111",
                    "dbport": "dbport111",
                    "cluster_name": "cluster_name111",
                    "role": "role111",
                    "online": "true",
                    "maintain": "true",
                },
                {
                    "host": "host1111",
                    "dbport": "dbport1111",
                    "cluster_name": "cluster_name1111",
                    "role": "role1111",
                    "online": "true",
                    "maintain": "true",

                },
            ]
    },
    {
        "cluster_name": "test22",
        "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "node_list":
            [
                {
                    "host": "host1",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "online": "false",
                    "maintain": "false",
                },
                {
                    "host": "host11",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "role11",
                    "online": "true",
                    "maintain": "true",
                },
                {
                    "host": "host111",
                    "dbport": "dbport111",
                    "cluster_name": "cluster_name111",
                    "role": "role111",
                    "online": "true",
                    "maintain": "true",
                },
                {
                    "host": "host1111",
                    "dbport": "dbport1111",
                    "cluster_name": "cluster_name1111",
                    "role": "role1111",
                    "online": "true",
                    "maintain": "true",

                },
            ]
    },
    {
        "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "cluster_name": "test11",
        "node_list":
            [
                {
                    "host": "host1",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "online": "false",
                    "maintain": "false",
                },
                {
                    "host": "host11",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "role11",
                    "online": "true",
                    "maintain": "true",
                },
                {
                    "host": "host111",
                    "dbport": "dbport111",
                    "cluster_name": "cluster_name111",
                    "role": "role111",
                    "online": "true",
                    "maintain": "true",
                },
                {
                    "host": "host1111",
                    "dbport": "dbport1111",
                    "cluster_name": "cluster_name1111",
                    "role": "role1111",
                    "online": "true",
                    "maintain": "true",

                },
                {
                    "host": "host1111",
                    "dbport": "dbport1111",
                    "cluster_name": "cluster_name1111",
                    "role": "role1111",
                    "online": "true",
                    "maintain": "false",

                },
                {
                    "host": "host1111",
                    "dbport": "dbport1111",
                    "cluster_name": "cluster_name1111",
                    "role": "role1111",
                    "online": "true",
                    "maintain": "false",

                },
            ]
    },
    {
        "cluster_name": "test33",
        "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "node_list":
            [
                {
                    "host": "host1",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "online": "false",
                    "maintain": "false",
                },
                {
                    "host": "host11",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "role11",
                    "online": "true",
                    "maintain": "true",
                },
                {
                    "host": "host111",
                    "dbport": "dbport111",
                    "cluster_name": "cluster_name111",
                    "role": "role111",
                    "online": "true",
                    "maintain": "true",
                },
                {
                    "host": "host1111",
                    "dbport": "dbport1111",
                    "cluster_name": "cluster_name1111",
                    "role": "role1111",
                    "online": "true",
                    "maintain": "true",

                },
            ]
    },
    {
        "cluster_name": "test34",
        "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "node_list":
            [
                {
                    "host": "host1",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "online": "false",
                    "maintain": "false",
                },
                {
                    "host": "host11",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "role11",
                    "online": "true",
                    "maintain": "true",
                },

            ]
    },
    {
        "cluster_name": "test35",
        "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "node_list":
            [
                {
                    "host": "host1",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "online": "false",
                    "maintain": "false",
                },
                {
                    "host": "host11",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "role11",
                    "online": "true",
                    "maintain": "true",
                },

            ]
    },
    {
        "cluster_name": "test36",
        "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "node_list":
            [
                {
                    "host": "host1",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "online": "false",
                    "maintain": "false",
                },
                {
                    "host": "host11",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "role11",
                    "online": "true",
                    "maintain": "true",
                },

            ]
    },
    {
        "cluster_name": "test37",
        "filed_list": ["rtype", "host", "dbport", "cluster_name", "online", "role"],
        "node_list":
            [
                {
                    "host": "host1",
                    "dbport": "dbport1",
                    "cluster_name": "cluster_name1",
                    "role": "role1",
                    "rtype": "db",
                    "online": "false",
                    "maintain": "false",
                },
                {
                    "host": "host11",
                    "dbport": "dbport11",
                    "cluster_name": "cluster_name11",
                    "role": "role11",
                    "online": "true",
                    "maintain": "true",
                },

            ]
    },
];